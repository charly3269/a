<footer class="bg-white shadow-md mt-8">
    <div class="container mx-auto px-4 py-6">
        <p class="text-center text-gray-600">© <?php echo date('Y'); ?> Sistema de Gestión. Todos los derechos reservados.</p>
    </div>
</footer>