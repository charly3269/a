<?php
session_start();
require_once '../../config/database.php';

// Filtrar por cliente si se proporciona un ID
$clientFilter = isset($_GET['client_id']) ? "AND t.client_id = " . intval($_GET['client_id']) : "";

// Obtener tareas archivadas
$query = "
    SELECT t.*, c.name as client_name, c.address, c.maps_url,
           (SELECT COUNT(*) FROM subtasks WHERE task_id = t.id) as total_subtasks,
           (SELECT COUNT(*) FROM subtasks WHERE task_id = t.id AND completed = 1) as completed_subtasks
    FROM tasks t
    JOIN clients c ON t.client_id = c.id
    WHERE t.archived_at IS NOT NULL {$clientFilter}
    ORDER BY t.archived_at DESC
";

$tasks = $pdo->query($query)->fetchAll();

// Calcular total
$total = 0;
foreach ($tasks as $task) {
    $total += $task['value'] - $task['expenses'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tareas Archivadas - Sistema de Gestión</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="/bolt/assets/css/styles.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <?php include '../../includes/header.php'; ?>

    <div class="container mx-auto px-4 py-8">
    <div class="flex flex-col space-y-4 md:space-y-0 md:flex-row md:justify-between md:items-center mb-6">
            <h1 class="text-3xl font-bold text-gray-800">Mantenimientos Archivados</h1>
        </div>

        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Cliente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Fecha/Hora</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Descripción</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Ubicación</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Subtareas</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Valor</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Gastos</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider table-cell-border">Archivado</th>
                    </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($tasks)): ?>
                            <tr>
                                <td colspan="9" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                    No hay tareas archivadas para mostrar.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($tasks as $task): ?>
                            <tr data-task-id="<?php echo $task['id']; ?>" class="hover:bg-gray-50 transition-colors duration-150">
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border">
                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($task['client_name']); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border">
                                    <div class="text-sm text-gray-900"><?php echo date('d/m/Y', strtotime($task['schedule_date'])); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo date('H:i', strtotime($task['schedule_time'])); ?></div>
                                </td>
                                <td class="px-6 py-4 table-cell-border">
                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($task['description']); ?></div>
                                </td>
                                <td class="px-6 py-4 table-cell-border">
                                    <?php if ($task['maps_url']): ?>
                                    <button onclick="toggleMap('map-<?php echo $task['id']; ?>', '<?php echo htmlspecialchars($task['maps_url']); ?>')"
                                            class="inline-flex items-center text-blue-600 hover:text-blue-900">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                        </svg>
                                        Ver mapa
                                    </button>
                                    <div id="map-<?php echo $task['id']; ?>" class="hidden mt-2"></div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 table-cell-border">
                                    <div class="text-sm text-gray-500">
                                        <?php echo $task['completed_subtasks']; ?>/<?php echo $task['total_subtasks']; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border">
                                    <div class="text-sm text-gray-500">$<?php echo number_format($task['value'], 2); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border">
                                    <div class="text-sm text-gray-500">$<?php echo number_format($task['expenses'], 2); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border">
                                    <div class="text-sm font-medium text-gray-900">$<?php echo number_format($task['value'] - $task['expenses'], 2); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap table-cell-border text-sm text-gray-500">
                                    <?php echo date('d/m/Y H:i', strtotime($task['archived_at'])); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr class="bg-gray-50">
                            <td colspan="7" class="px-6 py-4 text-right text-sm font-medium text-gray-900">Total General:</td>
                            <td colspan="2" class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                $<?php echo number_format($total, 2); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <?php include '../../includes/footer.php'; ?>
    <script src="/bolt/assets/js/main.js"></script>
    <script>
        function toggleMap(mapElementId, mapUrl) {
            const container = document.getElementById(mapElementId);
            if (!container) return;

            if (container.classList.contains('hidden')) {
                // Map is hidden, so show it and embed if not already embedded
                container.classList.remove('hidden');
                if (!container.querySelector('iframe')) {
                    embedMap(mapUrl, container);
                }
            } else {
                // Map is visible, so hide it
                container.classList.add('hidden');
            }
        }

        function embedMap(mapUrl, container) {
            const iframe = document.createElement('iframe');
            iframe.src = mapUrl;  // Use the URL directly
            iframe.width = '100%';
            iframe.height = '300';
            iframe.style.border = '0';
            iframe.allowFullscreen = true;

            container.innerHTML = '';
            container.appendChild(iframe);
        }
    </script>
</body>
</html>
